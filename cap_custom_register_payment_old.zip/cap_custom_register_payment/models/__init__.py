

from . import account_move
from . import account_payment
from . import res_config_settings
from . import res_partner

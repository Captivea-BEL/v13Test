* Odoo SA

  * Fabrice Henrion

* Open Source Integrators (https://opensourceintegrators.com)

  * Daniel Reis <dreis@opensourceintegrators.com>
  * Bhavesh Odedra <bodedra@opensourceintegrators.com>

* Serpent CS

  * Murtuza Saleh

* Sodexis

  * Atchuthan Ubendran

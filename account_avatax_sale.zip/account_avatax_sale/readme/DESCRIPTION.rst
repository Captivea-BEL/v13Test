This module is a component of the Avatax Integration with odoo app.
Please refer to the corresponding documentation.
